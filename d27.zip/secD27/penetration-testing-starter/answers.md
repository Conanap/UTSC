1. CVE-2012-1823
2. https://www.cvedetails.com/cve/CVE-2012-1823/
3. exploit/multi/http/php_cgi_arg_injection
